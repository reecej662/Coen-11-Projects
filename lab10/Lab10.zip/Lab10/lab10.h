#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#define name_size 10
#define header_size 50

//global variables
extern char* savefile;
extern pthread_mutex_t save_lock;

//Implement the structure for the customers
typedef struct NODE{
    char name[name_size];
    int num;
    struct NODE* next;
} NODE;

//function prototypes
NODE* insert(NODE* head, char* name, int num);
NODE* delete(NODE* head);
void display(NODE* head);
NODE* display_binary(char* file, NODE* temp);
NODE* getdata(char* list, NODE* head);
void save(char* list, NODE* head);
void* autosave(void* list);