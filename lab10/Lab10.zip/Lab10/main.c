//
//  lab10.c
//  lab 10
//
//  Reece Jackson
//  COEN 11
//

#include "lab10.h"

pthread_mutex_t save_lock;
char* savefile;

int main(int argc, char* argv[])
{
    //make sure there are enough elements
    if(argc != 2)
    {
        printf("Error: Not enough arguments.\n");
        return 1;
    }

	savefile = malloc(sizeof(char)*strlen(argv[1]));
	strcpy(savefile, argv[1]);

    //make the waiting list
    NODE* head = NULL;
    head = getdata(argv[1], head);

    //declare variables
    int input = 0;             //the input from the users

    //make autosave thread
	pthread_t saver;

	pthread_create(&saver, NULL, autosave, (void *) &head);

    while('true')
    {
        //provide the interface that instructs the user on how to use the menu
        printf("Please enter a numnber 1-5 based on the following options:\n1:Add\n2:Remove\n3:Display\n4:Display Binary\n5:Quit\n");
        scanf("%d", &input);
        printf("\n");

        //switch through the different optinos depending on the input
        switch(input)
        {
            case 1:
            {
                char tmp_name[name_size];
                int tmp_num;

                printf("What is the name of the reservation?\n");
                scanf("%s", tmp_name);

                printf("What is the size of the reservation?\n");
                scanf("%d", &tmp_num);

                head = insert(head, tmp_name, tmp_num);
                printf("\n");
                break;
            }
            case 2:
                head = delete(head);
                break;
            case 3:
                display(head);
                break;
            case 4:
            {
                NODE* temp = NULL;
                temp = display_binary(argv[1], temp);
                display(temp);
                break;
            }
            case 5:
            {
                pthread_mutex_lock(&save_lock);
                pthread_cancel(saver);
                save(argv[1], head);
                pthread_mutex_unlock(&save_lock);

                return 0;
            }
            default:
                printf("Enter a valid selection.\n\n");
                break;
        }
    }
}
