#include "lab10.h"

//file functions to manage reastauraunt waiting list

//load the specified file into the linked list to start out
NODE* getdata(char* list, NODE* head)
{
    //create the file pointer and open the file
    FILE* input = NULL;
    if((input = fopen(list, "rb")) == NULL)
    {
        printf("The waiting list cannot be opened.\n");
        return NULL;
    }

    //temporary variables
    char temp_name[name_size];
    int temp_num;

    //scan the string into the temporary variables until EOF and insert them into the list
    while((fread(&temp_name, sizeof(char), name_size, input) != 0 && (fread(&temp_num, sizeof(int), 1, input)) != 0))
    {
	    head = insert(head, temp_name, temp_num);
    }

    //close the file and return
    fclose(input);
    return head;
}

//save the list into the specified file
void save(char* list, NODE* head)
{
    //create file pointer and open the file
    FILE* output = NULL;
    if((output = fopen(list, "wb")) == NULL)
    {
        printf("The waiting list cannot be saved.\n");
        return;
    }

    //make pointers to traverse the list
    NODE* curr = head;
    NODE* prev = head;

    //copy elements into the linked list freeing as you go
    while(curr != NULL)
    {
        // fprintf(output, "%s %d\n", curr->name, curr->num);
        fwrite(curr->name, sizeof(char), name_size, output);
        fwrite(&curr->num, sizeof(int), 1, output);
        prev = curr;
        curr = curr->next;
    }

    //close the file
    fclose(output);
}

//worker function to save the list every 5 seconds
void* autosave(void* list)
{
    while('true')
    {
        NODE* head = *((NODE**)list);

        pthread_mutex_lock(&save_lock);
        save(savefile, head);
        pthread_mutex_unlock(&save_lock);

        sleep(5);
    	printf("Saving...\n");
    }
}

//display data currently saved in binary file
NODE* display_binary(char* file, NODE *temp)
{
    temp = getdata(file, temp);
    return temp;
}
